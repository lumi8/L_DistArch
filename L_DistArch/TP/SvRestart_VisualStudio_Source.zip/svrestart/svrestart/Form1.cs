using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace svrestart;

public class Form1 : Form
{
	private PictureBox pictureBox1;

	private Label label1;

	private Timer timer1;

	private IContainer components;

	public int m_ProcessID;

	public string m_szProcessPath = "";

	public string m_szProcessArgument = "";

	public string m_szMessage = "";

	public Form1(int nProcID, string szProcPath, string szProcArgs, string szMessage)
	{
		InitializeComponent();
		m_ProcessID = nProcID;
		m_szProcessPath = szProcPath;
		if (szProcArgs.Length > 0)
		{
			m_szProcessArgument = szProcArgs;
		}
		if (szMessage.Length > 0)
		{
			m_szMessage = szMessage;
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.Resources.ResourceManager resourceManager = new System.Resources.ResourceManager(typeof(svrestart.Form1));
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.label1 = new System.Windows.Forms.Label();
		this.timer1 = new System.Windows.Forms.Timer(this.components);
		base.SuspendLayout();
		this.pictureBox1.Image = (System.Drawing.Image)resourceManager.GetObject("pictureBox1.Image");
		this.pictureBox1.Location = new System.Drawing.Point(8, 8);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(32, 32);
		this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.pictureBox1.TabIndex = 0;
		this.pictureBox1.TabStop = false;
		this.label1.Location = new System.Drawing.Point(56, 16);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(232, 32);
		this.label1.TabIndex = 1;
		this.label1.Text = "Relaunching PcVue, please wait... ";
		this.timer1.Interval = 1000;
		this.timer1.Tick += new System.EventHandler(timer1_Tick);
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		base.ClientSize = new System.Drawing.Size(306, 50);
		base.ControlBox = false;
		base.Controls.Add(this.label1);
		base.Controls.Add(this.pictureBox1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Name = "Form1";
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		base.Load += new System.EventHandler(Form1_Load);
		base.ResumeLayout(false);
	}

	[STAThread]
	private static void Main(string[] args)
	{
		int length = args.GetLength(0);
		if (length < 2)
		{
			MessageBox.Show("Missing command-line arguments for SVRestart : [PIdOfProcessToWait] [\"CommandLineToReLaunch\"] [\"Arguments\"] [\"Message to display\"]  ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			return;
		}
		int nProcID = Convert.ToInt32(args[0]);
		string szProcPath = args[1];
		string text = "";
		string szMessage = "";
		if (length > 2)
		{
			text = args[2];
		}
		if (length > 3)
		{
			szMessage = args[3];
		}
		text = text.Replace("|", "\"");
		Application.Run(new Form1(nProcID, szProcPath, text, szMessage));
	}

	private void Form1_Load(object sender, EventArgs e)
	{
		if (m_szMessage.Length > 0)
		{
			label1.Text = m_szMessage;
		}
		timer1.Enabled = true;
	}

	private void timer1_Tick(object sender, EventArgs e)
	{
		Process[] processes = Process.GetProcesses();
		int length = processes.GetLength(0);
		for (int i = 0; i < length; i++)
		{
			if (processes[i].Id == m_ProcessID)
			{
				return;
			}
		}
		timer1.Enabled = false;
		try
		{
			Process.Start(m_szProcessPath, m_szProcessArgument);
		}
		catch
		{
			MessageBox.Show("Unable to launch " + m_szProcessPath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
		Application.Exit();
	}
}
